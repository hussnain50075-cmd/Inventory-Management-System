#include "Person.h"
//ctor
Person::Person(string name,string email,string address, int phonenumber){
    this->name= name;
    this->email= email;
    this->address= address;
    this->phonenumber= phonenumber;
}
//setter
void Person::setname(string name){
    this->name= name;
}
void Person::setemail(string email){
    this->email= email;
}
void Person::setaddress(string address){
    this->address= address;
}
void Person::setphonenumber(int phonenumber){
    this->phonenumber= phonenumber;
}
//getter
string Person::getname()const{
    return name;
}
string Person::getemail()const{
    return email;
}
string Person::getaddress()const{
    return address;
}
int Person::getphonenumber()const{
    return phonenumber;
}
//dtor
Person::~Person(){}
