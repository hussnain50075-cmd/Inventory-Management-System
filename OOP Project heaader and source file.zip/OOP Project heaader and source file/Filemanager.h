#ifndef FILEMANAGER_H_INCLUDED
#define FILEMANAGER_H_INCLUDED

#include <vector>
#include <fstream>
#include "Product.h"
#include "Supplier.h"
#include "Sale.h"
#include "Reportgenerator.h"

class Filemanager{
private:
    string basspass;
public:
    Filemanager(string basspass);
    void saveproduct(vector<Product> product);
    vector<Product> loadproduct();
    void savesupplier(vector<Supplier> supplier);
    vector<Supplier> loadsupplier();
    void savesales(vector<Sale> sales);
    vector<Sale> loadsales();
    void savestockreport(vector<Product>& product);
    void savesalesreport(vector<Sale>& Sales,string fromdate, string todate);
    void savelowstockreport( vector<Product> lowstock);
};
#endif // FILEMANAGER_H_INCLUDED
