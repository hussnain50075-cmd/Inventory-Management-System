#ifndef PERSON_H_INCLUDED
#define PERSON_H_INCLUDED

#include <iostream>
using namespace std;

class Person{
private:
    string name;
    string email;
    string address;
    int phonenumber;
public:
    Person(string name,string email,string address, int phonenumber);
    void setname(string name);
    void setemail(string email);
    void setaddress(string address);
    void setphonenumber(int phonenumber);
    string getname()const;
    string getemail()const;
    string getaddress()const;
    int getphonenumber()const;
    virtual void display()const=0;
    ~Person();
};


#endif // PERSON_H_INCLUDED
